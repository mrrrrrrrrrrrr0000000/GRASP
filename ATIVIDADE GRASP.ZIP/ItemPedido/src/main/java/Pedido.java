import java.util.ArrayList;
import java.util.List;

public class Pedido {

    private final List<ItemPedido> itens;

    public Pedido() {
        itens = new ArrayList<>();
    }

    /*
     * GRASP - Creator
     * A classe Pedido é responsável por criar objetos ItemPedido,
     * pois ela contém e gerencia esses objetos.
     */
    public void adicionarItem(String nome, double preco) {
        ItemPedido item = new ItemPedido(nome, preco);
        itens.add(item);
    }

    public double calcularTotal() {
        double total = 0;

        for (ItemPedido item : itens) {
            total += item.getPreco();
        }

        return total;
    }

    public void listarItens() {
        for (ItemPedido item : itens) {
            System.out.println(item.getNome() + " - R$ " + item.getPreco());
        }
    }
}