public class SistemaPedidos {

    private final Pedido pedido;

    public SistemaPedidos() {
        pedido = new Pedido();
    }

    /*
     * GRASP - Controller
     * Esta classe recebe as solicitações do usuário
     * e coordena as operações do sistema.
     */
    public void adicionarProduto(String nome, double preco) {
        pedido.adicionarItem(nome, preco);
    }

    public void mostrarPedido() {
        pedido.listarItens();
        System.out.println("Total: R$ " + pedido.calcularTotal());
    }
}