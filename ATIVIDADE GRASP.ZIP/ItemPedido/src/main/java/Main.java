public class Main {

    public static void main(String[] args) {

        SistemaPedidos sistema = new SistemaPedidos();

        sistema.adicionarProduto("Mouse", 50.0);
        sistema.adicionarProduto("Teclado", 120.0);
        sistema.adicionarProduto("Monitor", 800.0);

        sistema.mostrarPedido();
    }
}